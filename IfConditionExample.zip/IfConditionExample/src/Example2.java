
public class Example2 {

	public static void main(String[] args) {
		int age = 17;

		if (age < 18) {
			System.out.println("age is less than 18");
		} else {
			System.out.println("hello");
			System.out.println("java");
		}
	}
}
