
public class Example1 {

	public static void main(String[] args) {
		int age = 18;
		if (age <= 18) {
			System.out.println("age is less than 18");
		}
	}
}
