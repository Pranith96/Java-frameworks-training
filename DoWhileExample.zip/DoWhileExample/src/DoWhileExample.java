
public class DoWhileExample {

	public void printNum() {
		int i = 0;

		do {
			System.out.println(i);
			i++;
		} while (i < 10);
	}

}
