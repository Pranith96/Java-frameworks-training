
public class Example {

	public static void main(String[] args) {
		DoWhileExample ex = new DoWhileExample();
		ex.printNum();
	}
}
