
public class MotorBike2 extends MotorBike {

	@Override
	public void hello(String word) {
		word = word.toLowerCase();
		System.out.println(word);
	}
}
