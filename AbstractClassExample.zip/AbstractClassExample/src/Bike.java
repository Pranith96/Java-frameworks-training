
public abstract class Bike {

	public void engine() {
		System.out.println("In bike engine");
	}

	public abstract void tire();

	public abstract void petrolTank();

	public abstract void hello(String word);

	public abstract int getNum(int value);
}
