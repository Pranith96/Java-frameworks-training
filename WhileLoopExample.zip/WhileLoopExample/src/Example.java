
public class Example {

	public static void main(String[] args) {
		WhileLoopExample ex = new WhileLoopExample();
		ex.print10EvenNum();
		System.out.println(".............");
		ex.print10Num();
		System.out.println("..................");
		ex.print10OddNum();
	}
}
