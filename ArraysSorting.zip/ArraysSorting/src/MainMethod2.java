
public class MainMethod2 {

	public static void main(String[] args) {
		Example2 ex2 = new Example2();
		ex2.swap();
	}
}
