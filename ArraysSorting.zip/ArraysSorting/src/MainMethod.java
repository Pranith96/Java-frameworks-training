
public class MainMethod {

	public static void main(String[] args) {
		Example ex = new Example();
		ex.sortElements1();
		System.out.println("...........");
		ex.sortElements2();
		System.out.println("....................");
		ex.largestElements();
	}
}
