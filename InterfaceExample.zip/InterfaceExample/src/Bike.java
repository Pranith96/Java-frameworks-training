
public interface Bike {

	public void tire();

	public void engine();

	public void petrolTank();

	public void hello(String word);

	public int getNum(int value);
}
