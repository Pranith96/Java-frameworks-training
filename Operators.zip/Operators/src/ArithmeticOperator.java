
public class ArithmeticOperator {

	public static void main(String[] args) {
		int x = 10;
		int y = 20;
		int z = x + y;
		System.out.println(z);

		int a = y - x;
		System.out.println(a);

		int p = y * x;
		System.out.println(p);
		int q = y / x; //   20/10 = 2 
		System.out.println(q);

		int w = y % x;  //  20 % 10 = 0
		System.out.println(w);
	}
}
