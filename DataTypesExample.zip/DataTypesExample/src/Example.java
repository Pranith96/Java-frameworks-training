
public class Example {

	public static void main(String[] args) {
		boolean b = true; // false
		byte b1 = 125;
		int i = 10000;
		short s = 1234;
		long l = 123456789L;
		float f = 12.5f;
		double d = 23456.343d;
		char c = 'a';
		char e = '1';
		char p = '@';
		String s1 = "hello";
		String s3 = "12456";
		String s4 = "hello123 @ ";
		String[] str = { "hi1@", "wrold", "sds" };
		int[] k = { 10, 2, 12 };
		System.out.println(b);
		System.out.println(str);
	}
}
