
public class MainClass {

	public static void main(String[] args) {
//		Example ex = new Example();
//		ex.printNum();
//		System.out.println(".............reverse loop............");
//		Example2 ex2 = new Example2();
//		ex2.printReverseNum();
		
		PatternPrinting1 pr = new PatternPrinting1();
		pr.pattern1();
		System.out.println(".........");
		pr.pattern2();
	}
}
