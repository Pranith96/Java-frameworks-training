
public class Example2 {

	public void printReverseNum() {

		// 0-10 --> 10-0

		for (int i = 50; i > 0; i--) {
			if(i%2==0) {
				System.out.println(i);
			}
		}
	}

}
