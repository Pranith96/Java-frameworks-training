
public class ForloopExample {

	public void print5Num() {
		for (int i = 0; i < 5; i++) {
			System.out.println(i);
		}
	}

	public void printOddNumUpto10() {
		for (int i = 0; i < 10; i++) {
			if (i % 2 != 0) {
				System.out.println(i);
			}
		}
	}
}
