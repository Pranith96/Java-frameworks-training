//
//public class Multiplication extends Subtraction {
//
//	public void hello() {
//		System.out.println("hello");
//	}
//}
