
public class Addition {

	public void add(int x, int y) {
		int z = x + y;
		System.out.println(z);
	}

	public void printNum(int num) {

		for (int i = 0; i < num; i++) {
			System.out.println(i);
		}
	}
}
