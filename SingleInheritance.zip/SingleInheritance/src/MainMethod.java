
public class MainMethod {

	public static void main(String[] args) {
		Subtraction sb = new Subtraction();
		sb.hi();
		sb.add(10, 20);
		sb.printNum(5);
	}
}
