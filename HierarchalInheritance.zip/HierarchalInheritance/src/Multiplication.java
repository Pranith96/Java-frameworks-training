
public class Multiplication extends Addition {

	public void hello() {
		System.out.println("hello");
	}
}
