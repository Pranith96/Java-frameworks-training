
public class MainMethod {

	public static void main(String[] args) {
		Subtraction sb = new Subtraction();
		sb.hi();
		sb.add(10, 20);
		sb.printNum(5);
		
		Multiplication m = new Multiplication();
		m.add(20, 20);
		m.printNum(3);
		m.hello();
	}
}
