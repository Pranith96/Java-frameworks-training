
public class Calculator {

	public void add(int a, int b) {
		int c = a + b;
		System.out.println(c);
	}

	public void sub(int a, int b) {
		int c = a - b;
		System.out.println(c);
	}

	public void mul(int a, int b) {
		int c = a * b;
		System.out.println(c);
	}

	public void div(int a, int b) {
		int c = a / b;
		System.out.println(c);
	}
}
