
public class SBIBankImpl implements Bank{

	@Override
	public float getInterestRate() {
		return 8.2f;
	}
}
