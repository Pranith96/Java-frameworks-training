
public class HDFCBankImpl implements Bank {

	@Override
	public float getInterestRate() {
		return 8.4f;
	}

}
