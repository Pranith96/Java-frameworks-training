
public class ICICIBankImpl implements Bank {

	@Override
	public float getInterestRate() {
		return 8.5f;
	}

}
