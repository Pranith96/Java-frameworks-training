
public interface Bank {

	public float getInterestRate();
}
