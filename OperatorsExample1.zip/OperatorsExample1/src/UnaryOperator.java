
public class UnaryOperator {

	public static void main(String[] args) {
		int i = 10;
		i++; // i+1 --> 10+1 ==11
		System.out.println(i);

		int j = 10;
		j--; // j-1 --> 10-1 =9
		System.out.println(j); //9
		j++; //10
		System.out.println(j);
	}
}
