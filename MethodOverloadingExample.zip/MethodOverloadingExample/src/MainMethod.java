
public class MainMethod {

	public static void main(String[] args) {
		Addition ad = new Addition();
		ad.add(10, 10);
		ad.add(10, "Hello");
		ad.add(20, 20, 20);
	}
}
