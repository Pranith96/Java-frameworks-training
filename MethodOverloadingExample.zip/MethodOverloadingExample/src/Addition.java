
public class Addition {

	public void add(int a, int b) {
		int c = a + b;
		System.out.println(c);
	}

	public void add(int a, int b, int c) {
		int d = a + b + c;
		System.out.println(d);
	}

	public void add(int a, String word) {
		String data = a + word;
		System.out.println(data);
	}
}
